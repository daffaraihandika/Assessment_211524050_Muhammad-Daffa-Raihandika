import React from "react";

const AdminList = () => {
  return <div>Isi Konten Disini</div>;
};

export default AdminList;
