import React from "react";

const AdminEdit = () => {
  return <div>Isi Konten Disini</div>;
};

export default AdminEdit;
